﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Buoi6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                StudentContextDB context = new StudentContextDB();
                List<Faculty> listFaculties = context.Faculties.ToList();
                List<Student> listStudent = context.Students.Include(s => s.Faculty).ToList(); // 👈 Include Faculty

                FillFacultyCombobox(listFaculties);
                BindGrid(listStudent);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadFaculties()
        {
            using (var context = new StudentContextDB())
            {
                var faculties = context.Faculties.ToList();
                cmbFaculty.DataSource = faculties;
                cmbFaculty.DisplayMember = "FacultyName";
                cmbFaculty.ValueMember = "FacultyID";
            }
        }

        private void LoadStudents()
        {
            using (var context = new StudentContextDB())
            {
                var students = context.Students.Include(s => s.Faculty).ToList(); // 👈 Đây là chìa khóa!
                BindGrid(students);
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvStudent.SelectedRows.Count > 0)
            {
                var student = dgvStudent.SelectedRows[0].DataBoundItem as Student;
                if (student != null)
                {
                    txtStudentID.Text = student.StudentID;
                    txtFullName.Text = student.FullName;
                    txtAverageScore.Text = student.AverageScore.ToString();
                    cmbFaculty.SelectedValue = student.FacultyID;
                }
            }
        }

        

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!ValidateInput(out string studentID, out string fullName, out float score))
                return;

            using (var context = new StudentContextDB())
            {
                if (context.Students.Any(s => s.StudentID == studentID))
                {
                    MessageBox.Show("Mã sinh viên đã tồn tại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var student = new Student
                {
                    StudentID = studentID,
                    FullName = fullName,
                    AverageScore = score,
                    FacultyID = (int)cmbFaculty.SelectedValue
                };

                context.Students.Add(student);
                context.SaveChanges();

                MessageBox.Show("Thêm mới dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                BindGrid(context.Students.ToList()); // Cập nhật lại grid
                ResetForm();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (!ValidateInput(out string studentID, out string fullName, out float score))
                return;

            using (var context = new StudentContextDB())
            {
                var student = context.Students.FirstOrDefault(s => s.StudentID == studentID);
                if (student == null)
                {
                    MessageBox.Show("Không tìm thấy MSSV cần sửa!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                student.FullName = fullName;
                student.AverageScore = score;
                student.FacultyID = (int)cmbFaculty.SelectedValue;

                context.SaveChanges();

                MessageBox.Show("Cập nhật dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                BindGrid(context.Students.ToList());
                ResetForm();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string studentID = txtStudentID.Text.Trim();
            if (string.IsNullOrWhiteSpace(studentID))
            {
                MessageBox.Show("Vui lòng chọn sinh viên cần xóa!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (var context = new StudentContextDB())
            {
                var student = context.Students.FirstOrDefault(s => s.StudentID == studentID);
                if (student == null)
                {
                    MessageBox.Show("Không tìm thấy MSSV cần xóa!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                var result = MessageBox.Show("Bạn có chắc chắn muốn xóa sinh viên này?", "Xác nhận",
                                             MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    context.Students.Remove(student);
                    context.SaveChanges();

                    MessageBox.Show("Xóa sinh viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    BindGrid(context.Students.ToList());
                    ResetForm();
                }
            }
        }

            private void ResetForm()
        {
            txtStudentID.Clear();
            txtFullName.Clear();
            txtAverageScore.Clear();
            cmbFaculty.SelectedIndex = 0;
            txtStudentID.Focus();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        private void btnReset_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bindingSource1_CurrentChanged(object sender, EventArgs e)
        {

        }


        private void frmStudentManagement_Load(object sender, EventArgs e)
        {
            try
            {
                StudentContextDB context = new StudentContextDB();
                List<Faculty> listFaculties = context.Faculties.ToList();
                List<Student> listStudent = context.Students.ToList();

                FillFacultyCombobox(listFaculties);
                BindGrid(listStudent);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FillFacultyCombobox(List<Faculty> listFaculties)
        {
            cmbFaculty.DataSource = listFaculties;
            cmbFaculty.DisplayMember = "FacultyName";
            cmbFaculty.ValueMember = "FacultyID";
        }

        private void BindGrid(List<Student> listStudent)
        {
            dgvStudent.Rows.Clear();
            foreach (var item in listStudent)
            {
                int index = dgvStudent.Rows.Add();
                dgvStudent.Rows[index].Cells[0].Value = item.StudentID;
                dgvStudent.Rows[index].Cells[1].Value = item.FullName;
                dgvStudent.Rows[index].Cells[2].Value = item.Faculty?.FacultyName ?? ""; // 👈 Thêm ? để tránh null
                dgvStudent.Rows[index].Cells[3].Value = item.AverageScore;
            }
        }

        private bool ValidateInput(out string studentID, out string fullName, out float score)
        {
            studentID = txtStudentID.Text.Trim();
            fullName = txtFullName.Text.Trim();
            score = 0;

            if (string.IsNullOrWhiteSpace(studentID))
            {
                MessageBox.Show("Vui lòng nhập mã sinh viên!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtStudentID.Focus();
                return false;
            }

            if (studentID.Length != 10)
            {
                MessageBox.Show("Mã số sinh viên phải có 10 ký tự!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtStudentID.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(fullName))
            {
                MessageBox.Show("Vui lòng nhập họ tên!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFullName.Focus();
                return false;
            }

            if (!float.TryParse(txtAverageScore.Text, out score) || score < 0 || score > 10)
            {
                MessageBox.Show("Điểm trung bình phải từ 0 đến 10!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAverageScore.Focus();
                return false;
            }

            return true;
        }

        private void dgvStudent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvStudent.Rows[e.RowIndex];
                txtStudentID.Text = row.Cells[0].Value?.ToString() ?? "";
                txtFullName.Text = row.Cells[1].Value?.ToString() ?? "";
                txtAverageScore.Text = row.Cells[3].Value?.ToString() ?? "";

                string facultyName = row.Cells[2].Value?.ToString();
                using (var context = new StudentContextDB())
                {
                    var faculty = context.Faculties.FirstOrDefault(f => f.FacultyName == facultyName);
                    if (faculty != null)
                    {
                        cmbFaculty.SelectedValue = faculty.FacultyID;
                    }
                }
            }
        }

        private void dgvStudent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
